PROJECT 18 - Flat rounded screen + Arabic-Indic time (cream background, soft shadow)
1) Zip extract: /storage/emulated/0/mockup_project_18
2) Wallpapers 18_wallpapers me daalo (1 wallpaper = 1 mockup + 1 ready wallpaper)
3) cd /storage/emulated/0/mockup_project_18 && python w18.py
   python w18.py del -> delete menu | python w18.py batch -> batch
Time tracker SHARED (/storage/emulated/0/.mockup_time_tracker.txt): pichle project ke baad wahi se aage ka waqt.
Settings w18.py ke upar: TIME_DIGITS ("arabic"/"latin"), TIME_24H, TEXT_STYLE ("tinted"/"white"), BG_RGB, INNER_SHADOW (andar ka shadow, 0 = band).
Arabic font badalna ho to fonts/FreeSerifBold.ttf ki jagah apna font isi naam se rakh do.
