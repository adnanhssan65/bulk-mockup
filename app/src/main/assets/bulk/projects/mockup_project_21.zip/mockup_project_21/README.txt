PROJECT 21 — LIVE PHOTO MAKER — FINAL v7 (SAMSUNG)
===================================
Phone par sabit ho gaya (2026-11-25): Vivo gallery aur TikTok sirf
SAMSUNG Galaxy S23+ wali Motion Photo saakht ko hi Live Photo mante
hain. v1-v5 ke saare tareeqay (iOS pair / Vivo pair / Google single /
Oppo) FAIL hue the — un sab me Samsung ki asal SEF saakht ghaib thi.
v6 TEST me Samsung construction phone par PASS hui; ye FINAL v7 usi
jeeti hui saakht ko saaf, ek-output wale final roop me deta hai.

Input : VIDEO — 21_wallpapers folder me .mp4 / .mov / .m4v (kisi bhi
        lambai ki). TermuxMod/Project 21 drop folder ki videos bhi
        process se pehle khud input me ah jati hain (drop-fetch).
Output: har video se sirf DO outputs bante hain (clip EK hi dafa
        encode hoti hai — darmiyan wale 3 second, CRF 0 lossless;
        photo = bilkul beech wala frame, full resolution, full
        quality). HD mode Project 1 ki tarah hai: photo par family
        wala HD enhance, clip ki encode par halka denoise + sharpen
        filter — phir CRF 0 lossless, yani HD result bilkul waisa hi
        save hota hai. Mode setting me save rehta hai (.p21_mode
        file) — default HD; setting command se Normal bhi ho sakta
        hai (Normal = bilkul asal, koi enhance/filter nahi) —
        1) Mockup     : Mockups me, odd number — frame par lockscreen
                        design (bilkul reference jesa). Ghari aur date
                        asal waqt ki chhapti hai: run ke pehle mockup
                        par usi waqt ka time, har agle mockup par
                        +1 minute, aur date usi din ki.
        2) Live Photo : Ready Wallpapers me, even number, <n>.jpg —
                        asal Samsung mpv3 Motion Photo: JPEG ke andar
                        minimal EXIF (Make 'samsung', Model
                        'SM-S918B') + Google XMP (GCamera:MotionPhoto),
                        EOI ke baad [MotionPhoto_Data block][MP4]
                        [MotionPhoto_Version block 'mpv3']
                        [SEFH footer] — Samsung ki SEF tartib.
        Gallery copies TermuxMod/Project 21 me tartib se lag jati
        hain (mockup Mockups me, Live Photo Ready Wallpapers me) —
        har file ki sirf ek copy. Kaamyab video input se delete ho
        jati hai.

Commands:
  w21  ->  python w21.py process 21   (koi sawal nahi — bilkul automatic)
  d21  ->  python w21.py del 21       (delete menu, backup ke sath)
  b21  ->  python w21.py batch 21     (Ready_Upload_Batches me copy)
         python w21.py setting 21     (mode menu: HD / Normal — save ho jata hai)

LAZMI: ffmpeg installed ho. Na ho to pehle ye chalao:
  pkg install -y ffmpeg

Files: w21.py (runner), template.png + screen_mask.png (lockscreen
       design), fonts/ (ghari ke fonts), poster.jpg (app ki Run list
       ke liye — runner ise ignore karta hai).
Samsung format: spec reviventura/LivePhotoTools (docs/FORMATS.md);
       construction aviv926/MotionPhoto2 se port — MIT license
       LICENSE.txt me hai.
