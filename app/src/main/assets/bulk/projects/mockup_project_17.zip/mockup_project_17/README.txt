PROJECT 17 - iPhone on stand (white wall + marble), real lock-screen UI
1) Zip extract: /storage/emulated/0/mockup_project_17
2) Wallpapers 17_wallpapers me daalo (1 wallpaper = 1 mockup + 1 ready wallpaper)
3) cd /storage/emulated/0/mockup_project_17 && python w17.py
   python w17.py del -> delete menu | python w17.py batch -> batch
Time tracker SHARED (/storage/emulated/0/.mockup_time_tracker.txt): pichle project ke baad wahi se aage ka waqt.
Settings w17.py ke upar: CARRIER_TEXT ("Jio"), TIME_MODE, TEXT_STYLE ("tinted"/"white"), BATTERY_RANGE.
