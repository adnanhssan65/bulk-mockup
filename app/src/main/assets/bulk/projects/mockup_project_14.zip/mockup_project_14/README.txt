PROJECT 14 - Customized Background (Lock Screen + Home Screen)
1) Zip extract karo: /storage/emulated/0/mockup_project_14
2) 2 ya zyada wallpapers 14_wallpapers me daalo (jodi me banti hain: kala = Lock, roshan = Home)
3) Termux: cd /storage/emulated/0/mockup_project_14 && python w14.py
Output: 14_Mockups (mockup) + 14_Ready_Wallpapers (1080x1920).
Settings w14.py ke upar: TITLE_TEXT, LABEL_*, CARRIER_TEXT, TIME_MODE, WIDGETS, CITY_LAT/LON.
