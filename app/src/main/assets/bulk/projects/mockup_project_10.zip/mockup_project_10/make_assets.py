# shape.png (3 red screens, reference ke 2x layout) + backgrounds generator
import numpy as np, cv2, os
from PIL import Image, ImageDraw, ImageFilter
W, H = 2160, 2096                       # reference 1080x1048 ka 2x
XS = [72, 764, 1458]; Y0, PW, PH, R = 366, 630, 1368, 78
def rr_mask(scale=4):
    m = Image.new("L", (W*scale, H*scale), 0); d = ImageDraw.Draw(m)
    for x in XS: d.rounded_rectangle([x*scale, Y0*scale, (x+PW)*scale-1, (Y0+PH)*scale-1], radius=R*scale, fill=255)
    return m.resize((W, H), Image.LANCZOS)
mask = np.array(rr_mask())
shape = np.zeros((H, W, 3), np.uint8); shape[..., 2] = mask   # BGR: red channel
cv2.imwrite("shape.png", shape)


# --- project 8 ke ASAL backgrounds ka look: 8 edge/corner rang (3x3 grid, centre = edges ka average)
#     smooth gradient + har phone ke gird halka dark soft shadow (screens ke beech ka hissa gehra)
old = "../mockup_project_8/backgrounds"
def patch(im, cx, cy, r=10):
    H0, W0 = im.shape[:2]; x0, x1 = max(0, cx-r), min(W0, cx+r); y0, y1 = max(0, cy-r), min(H0, cy+r)
    return im[y0:y1, x0:x1].reshape(-1, 3).mean(0)
def grid_from(im):
    H0, W0 = im.shape[:2]; e = 8
    xs = [e, W0//2, W0-e]; ys = [e, H0//2, H0-e]
    g = np.zeros((3, 3, 3), np.float32)
    for j, y in enumerate(ys):
        for i, x in enumerate(xs): g[j, i] = patch(im, x, y, 6)
    g[1, 1] = (g[0, 1] + g[2, 1] + g[1, 0] + g[1, 2]) / 4
    return g[..., ::-1]    # BGR -> RGB
grids = {}
for f in sorted(os.listdir(old)):
    grids[f] = grid_from(cv2.imread(os.path.join(old, f)))
# naya 10th: reference ka laal (upar roshan glow, neeche gehra)
red = np.array([[[120,18,22],[178,36,38],[120,18,22]],
                [[ 70, 8,10],[ 96,12,14],[ 70, 8,10]],
                [[ 28, 3, 4],[ 34, 4, 5],[ 28, 3, 4]]], np.float32)
grids["design_10_crimson_glow.png"] = red

SS = 50
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
blur = np.array(Image.fromarray(mask).filter(ImageFilter.GaussianBlur(SS))).astype(np.float32) / 255
blur = np.roll(blur, 10, axis=0)
shade = 1 - 0.34 * np.clip(blur * 1.25, 0, 1)
for name, g in grids.items():
    if "crimson" in name:
        base = cv2.GaussianBlur(cv2.resize(g, (W, H), interpolation=cv2.INTER_CUBIC), (0, 0), 120)
    else:
        # project 8 jesa seedha smooth gradient: TL -> TR / BL (plane), koi diagonal lakeer nahi
        TL, TR, BL = g[0, 0], g[0, 2], g[2, 0]
        gx = (xx / (W - 1))[..., None]; gy = (yy / (H - 1))[..., None]
        base = TL + (TR - TL) * gx + (BL - TL) * gy
    img = base * (shade[..., None] if "crimson" not in name else (1 - 0.55*np.clip(blur*1.25,0,1))[..., None])
    cv2.imwrite(os.path.join("backgrounds", name), cv2.cvtColor(np.clip(img, 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
print(len(grids), "backgrounds ready")
