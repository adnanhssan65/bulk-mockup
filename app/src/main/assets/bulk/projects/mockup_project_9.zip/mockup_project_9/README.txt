MOCKUP PROJECT 9  (real iPhone look)
=====================================
Run (Termux):   python w9.py process 9      -> mockup + ready wallpaper
                python w9.py batch 9        -> batch warehouse me
                python w9.py del 9          -> delete menu
Wallpapers "9_wallpapers" me daalo (jpg/png/webp/avif/heic/bmp/tiff/gif... sab).
Har wallpaper = 1 mockup + 1 ready 1080x1920 wallpaper.

Fonts: "fonts" folder me
  TimeSerif-Bold.ttf  -> bada time (Liberation Serif Bold)
  Inter-Medium.otf    -> date
  Inter-SemiBold.otf  -> upar left chota time
  Inter-Bold.otf      -> battery % number
Apna font chahiye to wahi file replace kar do (ya w9.py ke upar FONT_* badlo).

Backgrounds: "backgrounds" me apni images (jpg/png) bhi daal sakte ho, script khud best chunti hai.

Settings w9.py ke upar: TIME_MODE, STATUS_TIME_LEFT, CASE_MODE, TILT_MODE, TEXT_STYLE, BATTERY_MODE...
Fonts license: Liberation Serif & Inter = SIL Open Font License.
