Project 20 - iOS Liquid Glass Time + Depth (time subject ke peeche)
Run: python w20.py process   (20_wallpapers me images rakho)
- Subject mask: onnxruntime + models/u2netp.onnx (zip me bundled; na ho to khud download).
  onnxruntime na ho to Termux me khud install try karta hai; fail ho to GrabCut (bina model).
- Layout wallpaper ke hisab se: wide / stacked-left / stacked-right.
- Asli SF Pro font ho to fonts/ me SF-Pro-Display-Bold.otf (ya SF-Pro-Rounded-Bold.otf) rakh do, wahi use hoga.
- Har mockup pe time pichle se 1 minute aage (shared tracker).
