MOCKUP PROJECT 13 - hand-held iPhone lock screen mockup

Folder: /storage/emulated/0/mockup_project_13   |   Wallpapers: 13_wallpapers
Run:  python w13.py process 13  (batch / del / fix bhi Project 12 jaise)

shape.png nahi hai - screen ke corners w13.py me SCREEN_QUAD me hain.
Mockup ka purana time/date hata diya gaya hai; naya time asli (pehli image = abhi, agli +1 min).
Settings w13.py ke upar: TIME_FORMAT "24"/"12", clock/date position.
