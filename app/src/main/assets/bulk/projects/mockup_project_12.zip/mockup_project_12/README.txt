MOCKUP PROJECT 12 - iPhone lock screen mockup

Folder ko  /storage/emulated/0/mockup_project_12  me rakho.
Wallpapers  12_wallpapers  me daalo.

Run (Termux):
  python w12.py process 12     -> mockups + ready wallpapers banao
  python w12.py batch 12       -> batch pack
  python w12.py del 12         -> delete menu
  python w12.py fix 12         -> gallery repair

Lock screen: time, date, signal, wifi, battery, dynamic island, torch, camera, home bar - sab auto.
Time: pehli image = abhi ka asli time, har agli image +1 minute.
Settings w12.py ke upar (LOCK SCREEN ENGINE): TIME_FORMAT "12"/"24", battery range, clock size/position.
Packages: pillow, opencv-python, numpy, tqdm (Project 1 jaisa)
