PROJECT 15 - Hand-held white case iPhone (24h condensed time + battery widget)
1) Zip extract: /storage/emulated/0/mockup_project_15
2) Wallpapers 15_wallpapers me daalo (1 wallpaper = 1 mockup + 1 ready wallpaper)
3) cd /storage/emulated/0/mockup_project_15 && python w15.py
   python w15.py del   -> delete menu | python w15.py batch -> batch banao
Time tracker SHARED hai (/storage/emulated/0/.mockup_time_tracker.txt): project 14 ke baad 15 chalao to wahi se aage ka waqt.
Settings w15.py ke upar: TIME_24H, TIME_MODE, GLYPH_LEFT ("flower"/"heart"), TEXT_STYLE, BATTERY_RANGE.
